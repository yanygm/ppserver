为了更方便的说明如何使用该系列工具，举个例子
例如我的跑跑安装目录:
E:\Program Files (x86)\TianCity\PopKart\M01

1.PPRhoParser.exe解析rho文件
例子：
源文件路径填写：E:\Program Files (x86)\TianCity\PopKart\M01\Data
生成文件路径填写：E:\Program Files (x86)\TianCity\PopKart\M01\Data1（随便找个空文件夹即可，不存在也会自动创建）

2.解析后得到的bml文件用PPBMLXML工具解析生成xml文件(直接拖bml文件图标到工具图标上即可)

3.xml文件修改后再用PPBMLXML工具打包生成bml文件(直接拖xml文件图标到工具图标上即可)

4.在修改rho文件资源后，利用PPRhoEncoder.exe打包成rho文件(直接拖rho资源文件所在目录的上级目录图标到工具图标上即可)
例子：
在上面解析基础上，拖动Data1图标到PPRhoEncoder.exe上，执行完会生成各个rho文件，都在Data1目录下面

5.打包rho后，还要用PPAAAMaker.exe生成aaa.xml(同上,直接拖rho文件所在目录图标到工具图标上即可)
例子：
在上面打包基础上，拖动Data1图标到PPAAAMaker.exe上，执行完会在Data1下面生成aaa.xml

6.aaa.xml用PPBMLXML工具生成aaa.bml(直接拖xml文件图标到工具图标上即可)

7.再利用PPAAA.exe生成aaa.pk文件(直接拖bml文件到PPAAA.exe上即可)

8.如果想单独解aaa.pk文件，拖aaa.pk图标到PPAAA.exe上即可生成aaa.bml

注意：
1.不能解析rho2,3,4,5及以上的跑跑资源文件；
2.如果要改xml文件，不能自己创建一个xml来修改，必须先把bml文件解析后生成xml文件，在此基础上做修改，然后再打包成bml，否则会有问题；